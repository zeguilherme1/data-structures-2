#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

#define TRUE '1'
#define FALSE '0'
#define SUCCESS 0
#define FILE_NOT_FOUND -1
#define MALLOC_ERROR -2
#define NO_DATA_ERROR -3

typedef struct criteria
{
    char field_name[50];
    char field_value[50];
} Search_criteria;

void BinarioNaTela(char *arquivo);

/*
   integer_or_null:

   This function receives a string and compare if is a integer or a NULL

   Args:
       (char*) str: string that function will compare

   Return:
       atoi(str) if is a integer
       -1 if string is empty or NULL
*/
int integer_or_null(char *str);

/*
    csv_to_bin:

    This functions reads a csv and a binary file, then process
    all the csv into the binary file.

    Args:
        No args

    Return:
        0 if success or -1 if failed
*/
int csv_to_bin();

/*
    bin_to_text:

    This function reads the binary file and print it,
    formatting if there are null fields.

    Args:
        No args.

    Return:
        0 for success and -1 for failure

*/
int bin_to_text();

void scan_quote_string(char *str);

/*
    criteria_search:

    This function reads the file and the n numbers of searches
    each with m criteria fields.

    So it reads every record and checks if the record field is equal to the given criteria,
    if it is, then the record is printed.

    If no correspondence is found for a given search, a "not found" message is printed.

    Args:
        No args.
    Return:
        0 for success and -1 for failure
*/
int criteria_search();

/*
    search_rrn:

    This function reads a binary file and a RRN value, then reads the
    record based on the RRN position using read_rrn_record function.

    Args:
        No args

    Return:
        No return
*/
int search_rrn();



// castar pra ingles e fazer doc
char *meu_strtok(char **buffer, const char *delimitador);

#endif
