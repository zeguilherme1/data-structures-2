#include <stdio.h>
#include "header.h"
#include "utils.h"

Header *new_header()
{

    Header *new_header = (Header *)malloc(sizeof(Header));

    if (new_header == NULL)
    {
        return NULL;
    }

    new_header->status = TRUE;
    new_header->top = -1;
    new_header->nextRRN = 0;
    new_header->station_num = 0;
    new_header->station_pairs_num = 0;

    return new_header;
}

void save_header(FILE *bin_file, Header *header)
{
    rewind(bin_file);
    fwrite(&header->status, sizeof(char), 1, bin_file);
    fwrite(&header->top, sizeof(int), 1, bin_file);
    fwrite(&header->nextRRN, sizeof(int), 1, bin_file);
    fwrite(&header->station_num, sizeof(int), 1, bin_file);
    fwrite(&header->station_pairs_num, sizeof(int), 1, bin_file);
}

Header *read_binary_header(FILE *bin_file)
{
    Header *bin_header = new_header();

    if (bin_header == NULL)
        return NULL;

    fread(&bin_header->status, sizeof(char), 1, bin_file);
    fread(&bin_header->top, sizeof(int), 1, bin_file);
    fread(&bin_header->nextRRN, sizeof(int), 1, bin_file);
    fread(&bin_header->station_num, sizeof(int), 1, bin_file);
    fread(&bin_header->station_pairs_num, sizeof(int), 1, bin_file);

    return bin_header;
}

int read_header(FILE *bin_file, Header *bin_header)
{
    if (bin_file == NULL)
        return NO_DATA_ERROR;
    if (bin_header == NULL)
        return NO_DATA_ERROR;

    int verify = 0;

    verify += fread(&bin_header->status, sizeof(char), 1, bin_file);
    verify += fread(&bin_header->top, sizeof(int), 1, bin_file);
    verify += fread(&bin_header->nextRRN, sizeof(int), 1, bin_file);
    verify += fread(&bin_header->station_num, sizeof(int), 1, bin_file);
    verify += fread(&bin_header->station_pairs_num, sizeof(int), 1, bin_file);

    if (verify == 5)
        return 0;
    else
        return -1;
}
