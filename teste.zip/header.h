#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

typedef struct header
{
    char status;
    int top;
    int nextRRN;
    int station_num;
    int station_pairs_num;
} Header;

/*
    new_header:

    This function creates a new header and set up initial values

    Args:
        No args

    Return:
        (Header*) new_header: The generated header

*/
Header *new_header();

/*
    read_binary_header:

    This function reads the binary file header and stores the data in a Header struct.

    Args:
        (FILE*) bin_file: binary input file to read the header from

    Return:
        (Header*) pointer to the populated Header struct, or NULL if allocation fails
*/
Header *read_binary_header(FILE *bin_file);

/*
    save_header:

    This function save a header struct to a binary file

    Args:
        (FILE*) bin_file: binary output file
        (Header*) header: the header struct that will be saved

*/
void save_header(FILE *bin_file, Header *bin_header);

/*
    read_header:

    This function confirm the if header was successful read

    Args:
        (FILE*) bin_file: binary input file
        (Header*) header: the header struct that will be read

    Return:
        0 for success and -1 for fail

*/
int read_header(FILE *bin_file, Header *bin_header);

#endif
