#ifndef RECORD_H
#define RECORD_H

#define HEADER_SIZE 17
#define RECORD_SIZE 80
#define READ_BINARY_MODE "rb+"
#define WRITE_BINARY_MODE "wb+"

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include "header.h"
#include "utils.h"

typedef struct record
{
	char removed;
	int next_record;
	int station_code;
	int line_code;
	int next_station_code;
	int next_station_distance;
	int line_integration_code;
	int station_integration_code;

	int station_name_size;
	char *station_name;

	int line_name_size;
	char *line_name;
} Record;

/*
	new_record:

	This function creates a new record and set up initial values

	Args:
		No args

	Return:
		new_record: The generated record
*/
Record *new_record();

/*
	read_record:

	This function confirms if the record was successfully read

	Args:
		(FILE*) bin_file: binary input file
		(Record*) bin_record: the record struct that will be read

	Return:
		0 for success and -1 for fail

	*/
int read_record(FILE *bin_file, Record *bin_record);

/*
	print_record:

	Prints all fields of a Record in a formatted way

	Args:
		(Record*) bin_record: record to print

	Return:
		void
*/
void print_record(Record *bin_record);

/*
	free_record:

	This function frees memory allocated for a Record

	Args:
		(Record**) temp_record: pointer to pointer of record

	Return:
		void
*/

void free_record(Record **temp_record);

/*
	tokenize_record:

	This function receives a CSV line and converts it into a Record struct

	Args:
		(char*) buffer: line from CSV file separated by commas

	Return:
		temp_record: pointer to the created and filled Record
*/
Record *tokenize_record(char *buffer);

/*
	save_record_to_bin:

	This function writes a Record into a binary file in fixed-size format

	Args:
		(FILE*) bin_file: binary file opened in write mode
		(Record*) r: record to be written

	Return:
		void
*/
void save_record_to_bin(FILE *bin_filename, Record *new_record);

/*
	save_record:

	This function writes only the fixed-size fields of a Record into a binary file

	Args:
		(FILE*) bin_filename: binary file pointer
		(Record*) new_record: record to be written

	Return:
		void
   */
void save_record(FILE *bin_filename, Record *new_record);

/*
	matches_record_criteria:

	This function confirms if the record was successfully compared with the criteria

	Args:
		(Record*) bin_record: the record struct to be compared
		(Search_criteria*) criteria: the criteria struct that will be comparison parameter
		int num_fields: the number of fields to be compared

	Return:
		0 for success and -1 for fail

*/
int matches_record_criteria(Record *bin_record, Search_criteria *criteria, int num_fields);

/*
	read_rrn_record:

	This function reads a record by its RRN (Relative Record Number)

	Args:
		(FILE*) bin_file: binary file pointer
		(int) rrn: record index

	Return:
		pointer to Record if found, NULL otherwise
*/
Record *read_rrn_record(FILE *bin_file, int rrn);

#endif
